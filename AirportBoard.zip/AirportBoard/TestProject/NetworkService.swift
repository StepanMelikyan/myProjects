
import Foundation

final class NetworkService {
    private let session = URLSession.shared
    
    func getArrivals(completion: @escaping([Arrivals]) -> Void) {
        guard let url = URL(string: "https://api.rasp.yandex.net/v3.0/schedule/?apikey=" + ApiKey.apiKey + "&station=s9600216&transport_types=plane&event=arrival") else {
            return
        }
        
        session.dataTask(with: url) { (data, _, error) in
            guard let data = data else {
                return
            }
            do {
                let arrivals = try JSONDecoder().decode(ModelArrival.self, from: data)
                completion(arrivals.schedule)
                //                print(arrivals)
            } catch {
                print(error)
            }
        }.resume()
    }
    
    func getDepartures(completion: @escaping([Departures]) -> Void) {
        guard let url = URL(string: "https://api.rasp.yandex.net/v3.0/schedule/?apikey=" + ApiKey.apiKey + "&station=s9600216&transport_types=plane&event=departure") else {
            return
        }
        
        session.dataTask(with: url) { (data, _, error) in
            guard let data = data else {
                return
            }
            do {
                let departures = try JSONDecoder().decode(ModelDeparture.self, from: data)
                completion(departures.schedule)
                //                print(departures)
            } catch {
                print(error)
            }
        }.resume()
    }
    
 
    func getBaners(completion: @escaping (Baner) -> Void) {
        if let url = URL(string: "https://api.rasp.yandex.net/v3.0/copyright/?apikey=" + ApiKey.apiKey + "&format=json") {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Ошибка при выполнении запроса: \(error.localizedDescription)")
                    return
                }

                guard let data = data else {
                    print("Данные не получены")
                    return
                }
                print(data)

                do {
                    let decoder = JSONDecoder()
                    let banerModel = try decoder.decode(BanerModels.self, from: data)
                    let text = banerModel.copyright.text
                    let url = banerModel.copyright.url
                    print("Text: \(text)")
                    print("URL: \(url)")
                    let baner = Baner(text: text, url: url)
                    completion(baner)
                } catch let decodingError {
                    print("Ошибка при декодировании данных: \(decodingError.localizedDescription)")
                }
            }.resume()
        }
    }
}

    
    
    
    


