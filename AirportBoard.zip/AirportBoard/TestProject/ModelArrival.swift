struct ModelArrival: Decodable {
    let schedule: [Arrivals]
    enum CodingKeys: String, CodingKey {
        case schedule = "schedule"
    }
}

struct Arrivals: Decodable {
    let thread: Arrival
    var arrivalTime: String?
    
    enum CodingKeys: String, CodingKey {
        case arrivalTime = "arrival"
        case thread = "thread"
        
    }
}

struct Arrival: Decodable {
    var number: String?
    var name: String?
    var point: String?
    
    enum CodingKeys: String, CodingKey {
        case number = "number"
        case name = "vehicle"
        case point = "short_title"
    }
}


