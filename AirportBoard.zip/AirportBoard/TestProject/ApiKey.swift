
struct ApiKey {
    static let apiKey = "10b60671-860f-4aa0-aa5c-576a4379600e"
}
