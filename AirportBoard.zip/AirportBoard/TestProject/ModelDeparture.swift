struct ModelDeparture: Decodable {
    let schedule: [Departures]
    enum CodingKeys: String, CodingKey {
        case schedule = "schedule"
    }
}

    struct Departures: Decodable {
        let thread: Departure
        var departureTime: String?
      
        
        enum CodingKeys: String, CodingKey {
            case departureTime = "departure"
            case thread = "thread"
            
        }
    }

    struct Departure: Decodable {
        var number: String?
        var name: String?
        var point: String?
        
        enum CodingKeys: String, CodingKey {
            case number = "number"
            case name = "vehicle"
            case point = "short_title"
        }
    }
