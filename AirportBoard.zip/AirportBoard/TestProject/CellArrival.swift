
import UIKit

final class CellArrival: UITableViewCell {

    private var arrivalTime: UILabel = {
        let label = UILabel()
        label.text = "departureTime"
        label.textColor = .black
        return label
    }()
    
    private var number: UILabel = {
        let label = UILabel()
        label.text = "number"
        label.textColor = .black
        return label
    }()
    
    private var name: UILabel = {
        let label = UILabel()
        label.text = "name"
        label.textColor = .black
        return label
    }()
    
    
    private var point: UILabel = {
        let label = UILabel()
        label.text = "point"
        label.textColor = .black
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateCell(model: Arrivals) {
        arrivalTime.text = model.arrivalTime!
        number.text = model.thread.number!
        name.text = model.thread.name
        point.text = model.thread.point!
    }
    
    private func setupViews() {
        contentView.addSubview(arrivalTime)
        contentView.addSubview(number)
        contentView.addSubview(name)
        contentView.addSubview(point)
        setupConstraints()
    }
    
    private func setupConstraints() {
        arrivalTime.translatesAutoresizingMaskIntoConstraints = false
        number.translatesAutoresizingMaskIntoConstraints = false
        name.translatesAutoresizingMaskIntoConstraints = false
        point.translatesAutoresizingMaskIntoConstraints = false
           NSLayoutConstraint.activate([
            number.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            number.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),

            arrivalTime.topAnchor.constraint(equalTo: number.bottomAnchor),
            arrivalTime.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),

            point.topAnchor.constraint(equalTo: number .bottomAnchor),
            point.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),

            name.topAnchor.constraint(equalTo: point.bottomAnchor),
            name.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),

           ])
       }
}
