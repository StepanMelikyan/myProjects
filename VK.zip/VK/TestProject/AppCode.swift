//
//  AppCode.swift
//  TestProject
//
//  Created by Stepan on 09.07.2023.
//

struct AppCode {
    /// Здесь код Вашего приложения!
    static let appCode = "51696526"
}
