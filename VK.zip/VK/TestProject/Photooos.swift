//
//  Photo.swift
//  TestProject
//
//  Created by Stepan on 30.06.2023.
//

import Foundation
import UIKit

class Photooos: UITableViewController {
    override func viewDidLoad() {        super.viewDidLoad()
        tableView.backgroundColor = .white
        title = "Photo"
        setupViews()
    }
    func addphto() {
        let Image1 = UIImageView(frame: CGRect(x: 45, y: 100, width: 120, height: 120))
        Image1.image = UIImage(systemName: "figure.run")
        self.view.addSubview(Image1)
        
        let Image2 = UIImageView(frame: CGRect(x: 210, y: 100, width: 120, height: 120))
        Image2.image = UIImage(systemName: "figure.american.football")
        self.view.addSubview(Image2)
        
        let Image3 = UIImageView(frame: CGRect(x: 45, y: 250, width: 120, height: 120))
        Image3.image = UIImage(systemName: "figure.australian.football")
        self.view.addSubview(Image3)
        
        let Image4 = UIImageView(frame: CGRect(x: 210, y: 250, width: 120, height: 120))
        Image4.image = UIImage(systemName: "figure.basketball")
        self.view.addSubview(Image4)
        
        let Image5 = UIImageView(frame: CGRect(x: 45, y: 400, width: 120, height: 120))
        Image5.image = UIImage(systemName: "figure.skiing.downhill")
        self.view.addSubview(Image5)
        
        let Image6 = UIImageView(frame: CGRect(x: 210, y: 400, width: 120, height: 120))
        Image6.image = UIImage(systemName: "figure.hiking")
        self.view.addSubview(Image6)
    }
    
    private func setupViews() {
        addphto()
    }
    
    
}
