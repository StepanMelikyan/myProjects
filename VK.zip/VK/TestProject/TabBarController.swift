//
//  TabBarController.swift
//  TestProject
//
//  Created by Stepan on 30.06.2023.
//

import Foundation

import UIKit

final class TabBarController{
    func createTabBarController() {
        let bar = UITabBarController()
        bar.tabBar.tintColor = UIColor.black
        self.view.addSubview(bar.view)
    }
}
