//
//  ViewController.swift
//  VSCO
//
//  Created by Stepan on 08.02.2024.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate {

    @IBOutlet weak var Picture: UIImageView!
    @IBOutlet weak var addButton: UIButton!
    
    private var imagePicker: ImagePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imagePicker = ImagePicker(presentationController: self, delegate: self)
    }

    @IBAction func EditAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Editor", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "Editor") as! EditorViewController
        vc.picture = self.Picture.image
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func addAction(_ sender: Any) {
        self.imagePicker.present(from: sender as! UIView)
    }
    
}

extension ViewController: ImagePickerDelegate{
    func didSelect(image: UIImage?) {
        self.Picture.image = image
    }
    
    
}

