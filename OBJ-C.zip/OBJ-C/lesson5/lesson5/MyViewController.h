//
//  MyViewController.h
//  lesson5
//
//  Created by Stepan on 21.08.2023.
//

#import "MyViewController.h"

@interface MyViewController()

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *data; // Массив для хранения полученных данных

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];

    // Отправка GET-запроса для получения данных
    [self fetchData];
}

- (void)fetchData {
    NSString *urlString = @"YOUR_API_ENDPOINT"; //  URL вашего сервиса
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];

    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                            completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"Ошибка при загрузке данных: %@", error.localizedDescription);
        } else {
            // Разбор JSON-данных, предположим, что сервер возвращает JSON
            NSError *jsonError = nil;
            NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
            if (jsonError) {
                NSLog(@"Ошибка разбора JSON: %@", jsonError.localizedDescription);
            } else {
                // Извлечение данных из ответа сервера
                self.data = responseDict[@"items"]; // Предполагается, что items содержит данные для отображения
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.tableView reloadData];
                });
            }
        }
    }];

    [task resume];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }

    // Заполнение ячейки данными
    NSDictionary *item = self.data[indexPath.row];
    cell.textLabel.text = item[@"text"];
  

    return cell;
}

@end
