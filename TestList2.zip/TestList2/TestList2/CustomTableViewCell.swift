//
//  CustomTableViewCell.swift
//  TestList2
//
//  Created by Stepan on 05.03.2024.
//

import Foundation
import UIKit
class CustomTableViewCell: UITableViewCell {

    private var stackView: UIStackView!
    private var labels: [UILabel] = []

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupStackView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) не реализован")
    }

    private func setupStackView() {
        if stackView == nil {
            stackView = UIStackView()
            stackView.axis = .horizontal
            stackView.distribution = .fillEqually
            contentView.addSubview(stackView)
            stackView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                stackView.topAnchor.constraint(equalTo: contentView.topAnchor),
                stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
                stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
            ])
        }
    }

    func configure(segments: Int) {
        setupStackView()

        stackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        labels.removeAll()

        for _ in 0..<segments {
            let randomValue = Int.random(in: 1...100)
            let label = createRoundedLabel(with: "\(randomValue)")
            stackView.addArrangedSubview(label)
            labels.append(label)


            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
            label.addGestureRecognizer(tapGesture)
            label.isUserInteractionEnabled = true
        }
    }

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        guard let label = gesture.view as? UILabel else { return }
        
        UIView.animate(withDuration: 0.2, animations: {
            label.transform = label.transform.scaledBy(x: 0.8, y: 0.8)
        }) { _ in
            UIView.animate(withDuration: 0.2) {
                label.transform = .identity
            }
        }
    }

    private func createRoundedLabel(with text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.textAlignment = .center
        label.layer.borderWidth = 0.5
        label.layer.borderColor = UIColor.black.cgColor
        label.layer.cornerRadius = 5.0
        label.layer.masksToBounds = true
        return label
    }

    func updateRandomNumber() {
        guard let randomIndex = labels.indices.randomElement() else { return }
        let randomValue = Int.random(in: 1...100)
        labels[randomIndex].text = "\(randomValue)"
    }
}
