

import UIKit
import Charts
import UniformTypeIdentifiers
import MobileCoreServices

class ChartViewModel: NSObject {
    private var dataEntries: [ChartDataEntry] = []
    private var lineChartView: LineChartView

    init(chartView: LineChartView) {
        self.lineChartView = chartView
    }

    func setupChart() {
        let set1 = LineChartDataSet(entries: dataEntries, label: "Values")
        set1.colors = [NSUIColor.blue]
        set1.drawCirclesEnabled = false

        let data = LineChartData(dataSet: set1)
        lineChartView.data = data

        lineChartView.xAxis.valueFormatter = DateValueFormatter()
        lineChartView.xAxis.labelRotationAngle = -45
        lineChartView.xAxis.labelPosition = .bottom

        lineChartView.rightAxis.enabled = false
        lineChartView.legend.enabled = true

        lineChartView.scaleXEnabled = true
        lineChartView.scaleYEnabled = true
    }

    func loadCSV(from viewController: UIViewController) {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.text])
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        documentPicker.modalPresentationStyle = .formSheet

        viewController.present(documentPicker, animated: true)
    }



    func findViewController() -> UIViewController? {
        if let keyWindow = UIApplication.shared.windows.first(where: { $0.isKeyWindow }) {
            guard let rootViewController = keyWindow.rootViewController else {
                return nil
            }

            var stack = [rootViewController]

            while !stack.isEmpty {
                let currentViewController = stack.removeLast()

                if let presentedViewController = currentViewController.presentedViewController {
                    stack.append(presentedViewController)
                }

                if currentViewController.isKind(of: UINavigationController.self) {
                    if let visibleViewController = (currentViewController as? UINavigationController)?.visibleViewController {
                        stack.append(visibleViewController)
                    }
                }

                if currentViewController.isKind(of: UITabBarController.self) {
                    if let selectedViewController = (currentViewController as? UITabBarController)?.selectedViewController {
                        stack.append(selectedViewController)
                    }
                }

                if let viewController = currentViewController as? UIViewController {
                    return viewController
                }
            }
        }

        return nil
    }



    func applyTimeInterval(startDateText: String?, endDateText: String?) {
        guard let startDateText = startDateText, let endDateText = endDateText else {
            return
        }

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

        guard let startTimeInterval = dateFormatter.date(from: startDateText)?.timeIntervalSince1970,
              let endTimeInterval = dateFormatter.date(from: endDateText)?.timeIntervalSince1970 else {
            return
        }

        let xAxis = lineChartView.xAxis
        xAxis.axisMinimum = startTimeInterval
        xAxis.axisMaximum = endTimeInterval

        lineChartView.notifyDataSetChanged()
    }
}


extension ChartViewModel: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else {
            print("No URL selected")
            return
        }

        do {
            let csvData = try String(contentsOf: url)
            parseCSV(csvData: csvData)
        } catch {
            print("Error reading CSV file: \(error.localizedDescription)")
        }

        controller.dismiss(animated: true, completion: nil)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        controller.dismiss(animated: true, completion: nil)
    }

    private func parseCSV(csvData: String) {
        let rows = csvData.components(separatedBy: "\n")
        for row in rows {
            let columns = row.components(separatedBy: ",")
            if columns.count >= 2 {
                let dateString = columns[0].trimmingCharacters(in: .whitespacesAndNewlines)
                let valueString = columns[1].trimmingCharacters(in: .whitespacesAndNewlines)
                
                if let time = convertToTimestamp(dateString: dateString), let value = Double(valueString) {
                    let dataEntry = ChartDataEntry(x: time, y: value)
                    dataEntries.append(dataEntry)
                } else {
                    print("Error parsing date or value from CSV row: \(row)")
                }
            }
        }
        DispatchQueue.main.async {
            self.lineChartView.notifyDataSetChanged()
        }
    }

    private func convertToTimestamp(dateString: String) -> Double? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let date = dateFormatter.date(from: dateString) {
            return date.timeIntervalSince1970
        } else {
            print("Error converting date to timestamp")
            return nil
        }
    }
}
