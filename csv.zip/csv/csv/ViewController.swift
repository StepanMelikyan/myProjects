
import UIKit
import Charts

class ViewController: UIViewController {

    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var intervalTextField: UITextField!
    @IBOutlet weak var startDateTextField: UITextField!
    @IBOutlet weak var endDateTextField: UITextField!

    var viewModel: ChartViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = ChartViewModel(chartView: lineChartView)
        viewModel.loadCSV(from: self)
        setupChart()
    }

    func setupChart() {
        viewModel.setupChart()
        
    }

    @IBAction func loadCSVButtonTapped(_ sender: UIButton) {
        viewModel.loadCSV(from: self)
    }
   

    @IBAction func applyIntervalButtonTapped(_ sender: UIButton) {
        viewModel.applyTimeInterval(startDateText: startDateTextField.text, endDateText: endDateTextField.text)
    }

}

